import React from 'react'

export default function Info() {
  return (
    <div>
      <h2 style={{color:'#7ed321',fontWeight:'bold'}}>Info</h2>
      <p>
        Lorem ipsum in quisque non gravida non enim, malesuada ipsum vitae. Nec cursus morbi porta auctor non metus
        maecenas sagittis tellus odio fusce rutrum cursus lorem massa maecenas porta, porttitor nec lorem — morbi fusce
        sagittis.

        Pharetra nam, ligula — maecenas morbi donec pellentesque commodo morbi ligula, elementum, cursus nec sem amet
        urna mattis ligula. Morbi a arcu ligula sit molestie rutrum proin nam auctor risus: sem rutrum metus duis.

        Vitae et gravida congue malesuada at sodales quisque amet bibendum in vulputate ultricies quisque, in mauris
        eget ligula. Quam justo ultricies sapien eget nec eget vivamus fusce tempus sapien molestie magna eros pharetra
        porttitor. Elementum sapien curabitur ligula urna maecenas orci maecenas mattis sapien congue ornare integer a
        nulla, sem leo, at nulla justo duis odio curabitur congue. Sem magna ultricies maecenas mauris sodales duis: sit
        ut urna cursus ut donec nec tempus, eros nec urna sapien malesuada commodo curabitur pellentesque. Eros non
        mauris vulputate urna, auctor tempus: in sapien, vitae ut odio curabitur nibh integer in risus odio duis. Massa
        pharetra congue sed sodales nec tempus sagittis metus, leo risus gravida rutrum lorem sodales ultricies amet leo
        proin odio. Quam gravida rutrum vitae auctor nam — risus enim congue, urna ligula justo maecenas donec, sapien
        non metus sed.

        Maecenas vitae rutrum enim congue pellentesque risus ipsum auctor tempus quisque metus. Ipsum curabitur, at —
        enim arcu, maecenas, ligula justo integer, proin sagittis porta massa mattis diam gravida, sodales nulla
        bibendum vivamus, malesuada eget nec, et eu. In congue ut, nibh integer diam, pharetra odio at sit — ultricies
        sagittis nibh. Nec, sit, lorem congue mauris quisque gravida, sapien odio vulputate maecenas nam, vitae — sapien
        ut massa vulputate porttitor amet ut amet.
      </p>
    </div>
  )
}